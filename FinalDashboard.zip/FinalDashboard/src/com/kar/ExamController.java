package com.kar;

import java.io.IOException;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

/**
 * Servlet implementation class ExamController
 */
@WebServlet("/ExamController")
public class ExamController extends HttpServlet {
	private static final long serialVersionUID = 1L;
	int presentQuestion_index = 0;
	QuestionsUtility Q;
    public ExamController() {
        super();
  
    }
    
    @Override
	public void init() throws ServletException {
		// TODO Auto-generated method stub
		super.init();
		Q = new QuestionsUtility();
	}

	public void nextQ(){
    	presentQuestion_index++;
    	
    }
    public void prevQ(){
    	presentQuestion_index--;
    }
    
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		RequestDispatcher rd = request.getRequestDispatcher("Solve.jsp");
		
		Q.Category(request.getParameter("Start"));
		request.setAttribute("currentQuestion", presentQuestion_index);
		request.setAttribute("question",Q.question(presentQuestion_index));
		
		rd.forward(request, response);
	}

	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		//presentQuestion_index = (int)request.getParameter("next");
		System.out.println(request.getParameter("next"));
		RequestDispatcher rd = request.getRequestDispatcher("Solve.jsp");
		if(request.getParameter("previous")!=null ||request.getParameter("next")!=null ){
			if(request.getParameter("previous")!=null){
				System.out.println(Integer.parseInt(request.getParameter("previous")));
				presentQuestion_index = Integer.parseInt(request.getParameter("previous"));
				request.setAttribute("question",Q.question(presentQuestion_index));
				rd.forward(request, response);
				
			}
			if(request.getParameter("next")!=null){
				System.out.println(request.getParameter("next"));
				presentQuestion_index = Integer.parseInt(request.getParameter("next"));
				request.setAttribute("question",Q.question(presentQuestion_index));
				rd.forward(request, response);
			}
			
		}
		
//		if(request.getParameter("refresh") != null)
//		{
//		RequestDispatcher rd = request.getRequestDispatcher("Solve.jsp");
//		//Next Question toggle
//		if(request.getParameter("next") != null) {
//			request.setAttribute("next", null);
//			if(presentQuestion_index < Q.NumberOfQuestions()-1) {
//				nextQ();
//				request.setAttribute("question",Q.question(presentQuestion_index));
//				rd.forward(request, response);
//				//doGet(request, response);
//				//response.sendRedirect("Redirect?ADD=success");
//				
//			}
//			else {
//				request.setAttribute("question",Q.question(Q.NumberOfQuestions()-1));
//				rd.forward(request, response);
//				//doGet(request, response);
//			}
//		}
//		//Previous question toggle
//		if(request.getParameter("previous") != null) {
//			request.setAttribute("next", null);
//			if(presentQuestion_index > 0) {
//				prevQ();
//				request.setAttribute("question",Q.question(presentQuestion_index));
//				rd.forward(request, response);
//				//doGet(request, response);
//			}	
//			else {
//				request.setAttribute("question",Q.question(0));
//				rd.forward(request, response);
//				//doGet(request, response);
//			}
//		}
//		//Submit Question toggle
//			
//		}
//		else {
//			doGet(request, response);
//		}


		
	}

}
