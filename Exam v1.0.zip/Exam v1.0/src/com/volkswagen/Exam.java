package com.volkswagen;

public class Exam {
	String exam_name;
	int examiner_id;
	int id;
	
	
	public Exam() {
		super();
		// TODO Auto-generated constructor stub
	}
	public Exam(String exam_name, int examiner_id, int id) {
		super();
		this.exam_name = exam_name;
		this.examiner_id = examiner_id;
		this.id = id;
	}
	public String getExam_name() {
		return exam_name;
	}
	public void setExam_name(String exam_name) {
		this.exam_name = exam_name;
	}
	public int getExaminer_id() {
		return examiner_id;
	}
	public void setExaminer_id(int examiner_id) {
		this.examiner_id = examiner_id;
	}
	public int getId() {
		return id;
	}
	public void setId(int id) {
		this.id = id;
	}
	
	@Override
	public String toString() {
		return "Exam [exam_name=" + exam_name + ", examiner_id=" + examiner_id + ", id=" + id + "]";
	}
	
	
}
