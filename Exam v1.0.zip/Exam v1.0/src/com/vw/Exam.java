package com.vw;

import java.util.Iterator;
import java.util.List;

import org.hibernate.Query;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.hibernate.cfg.Configuration;

public class Exam {
	Session session = null;
	SessionFactory factory;
	List list = null;
	public Exam() {
		super();
		// TODO Auto-generated constructor stub
	}

	public List<String> Category(){
		
		
		
		try
		{
			
			factory=new Configuration().configure().buildSessionFactory();
			
			session=factory.openSession();
			Transaction tr=session.beginTransaction();
			Query query=session.createQuery("select e.exam_name from Exam e");
			list=query.list();
			
//			Iterator iter=list.iterator();
//			while(iter.hasNext())
//				{
//				System.out.println(iter.next());
//				}
			tr.commit();

		}
		catch(Exception e)
		{
			e.printStackTrace();
		}
		finally
		{
			session.flush();
			session.close();
		}
	
		
		return list;

		
	}

}
